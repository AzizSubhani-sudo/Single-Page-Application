import React, { useState, useEffect, useContext } from "react";
import { fetchUsers } from '../api/api';
import UserCard from '../components/UserCard';
import { ThemeContext } from "../context/ThemeContext";  // Import ThemeContext

const Users = () => {
    const [users, setUsers] = useState([]);
    const { isDarkMode } = useContext(ThemeContext);  // Get isDarkMode from context

    useEffect(() => {
        const loadUsers = async () => {
            try {
                const data = await fetchUsers();
                setUsers(data);
            } catch (err) {
                console.log('Error fetching users: ', err);
            }
        };

        loadUsers();
    }, []);

    return (
        <div 
            className={`min-h-screen p-6 ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-800'}`}>
            <h1 
                className={`text-3xl font-bold text-center mb-6 ${isDarkMode ? 'text-white' : 'text-blue-800'}`}>
                Meet Our Team
            </h1>

            <div 
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {users.map(user => (
                    <UserCard key={user.id} user={user} />
                ))}
            </div>
        </div>
    );
};

export default Users;
