import React from "react";
import { useNavigate } from "react-router-dom";
import backgroundImage from '../assets/background.jpg';
import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

const Home = () => {
    const navigate = useNavigate();
    const { isDarkMode } = useContext(ThemeContext);

    return (
        <div
            className={`relative h-screen w-full bg-cover bg-center ${isDarkMode ? 'bg-gray-800' : ''}`}
            style={{ backgroundImage: `url(${backgroundImage})` }}>
            <div 
                className="absolute inset-0 bg-opacity-50">
            </div>
            <div 
                className="absolute inset-0 flex flex-col items-end justify-center text-center px-4">
                <h1 
                    className={`text-4xl md:text-5xl mb-4 mr-30 ${isDarkMode ? 'text-white' : 'text-black'}`}>
                        Welcome to
                </h1>
                <h1 
                    className={`text-4xl md:text-5xl font-extrabold mb-4 mr-20 ${isDarkMode ? 'text-white' : 'text-black'}`}>
                        DevConnect.
                </h1>
                <p 
                    className={`text-[16px] mb-6 ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                        Building Innovative Software Solutions to Shape the Future.
                </p>
                <button
                    onClick={() => navigate('/users')}
                    className={`bg-blue-500 hover:bg-blue-600 font-bold py-3 px-8 rounded-full shadow-lg transition-transform transform hover:scale-105 mr-30 ${isDarkMode ? 'text-white' : 'text-black'}`}>
                    OUR TEAM
                </button>
            </div>
        </div>
    );
};

export default Home;
