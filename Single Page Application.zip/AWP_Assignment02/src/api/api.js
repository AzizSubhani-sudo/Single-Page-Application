import axios from "axios";

const API = axios.create({
    baseURL:'https://jsonplaceholder.typicode.com',
});

export const fetchUsers = async () => {
    try{
        const response = await API.get('/users');

        return response.data;
    }
    catch(err){
        console.log('Error fetching users: ', err);
        throw err;
    }
};