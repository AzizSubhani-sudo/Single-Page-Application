import { Link } from "react-router-dom";
import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

const Navbar = () => {
    const { toggleTheme, isDarkMode } = useContext(ThemeContext);

    return (
        <nav
            className={`flex items-center justify-between px-6 py-3 ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'} shadow-md`}>
            <div 
                className={`text-2xl flex font-bold ${isDarkMode ? 'text-white' : 'text-blue-800'}`}>
                <img
                    src="/src/assets/logo.png"
                    alt="DevConnect Logo"
                    className="w-8 h-auto rounded-2xl mr-1"
                />
                DevConnect
            </div>

            <div 
                className="flex items-center gap-6">
                <Link 
                    to="/" 
                    className="text-blue-700 hover:text-blue-400 transition-colors">
                    Home
                </Link>
                <Link 
                    to="/users" 
                    className="text-blue-700 hover:text-blue-400 transition-colors">
                    Users
                </Link>
                <button
                    onClick={toggleTheme}
                    className="ml-4 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors font-semibold">
                    {isDarkMode ? 'Light Mode' : 'Dark Mode'}
                </button>
            </div>
        </nav>
    );
};

export default Navbar;
