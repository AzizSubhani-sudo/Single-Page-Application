import React from 'react';
import { useContext } from "react";
import { ThemeContext } from "../context/ThemeContext";

const Footer = () => {
    const { isDarkMode } = useContext(ThemeContext);

    return (
        <footer 
            className={`${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'} py-6`}>
            <div 
                className="container mx-auto px-4 flex flex-col md:flex-row justify-center items-center">
                <div 
                    className="text-lg font-semibold">
                    © 2025 DevConnect. All rights reserved.
                </div>
            </div>
        </footer>
    );
};

export default Footer;
