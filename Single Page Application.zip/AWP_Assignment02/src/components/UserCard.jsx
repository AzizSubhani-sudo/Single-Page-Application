import React from "react";

const UserCard = ({ user }) => {
    return (
        <div 
            className="bg-blue-600 rounded-lg shadow-lg p-6 hover:shadow-xl hover:border-blue-800 transition-all duration-300 border border-transparent">
            <h2 
                className="text-2xl text-white font-semibold mb-4">
                {user.name}
            </h2>

            <p 
                className="text-gray-300 mb-2">
                <span 
                    className="font-medium text-gray-200">Username: </span>
                    {user.username}
            </p>

            <p 
                className="text-gray-300 mb-2">
                <span 
                    className="font-medium text-gray-200">Email: </span>
                    {user.email}
            </p>

            <p 
                className="text-gray-300 mb-2">
                <span 
                    className="font-medium text-gray-200">Phone: </span>
                    {user.phone}
            </p>

            <p 
                className="text-gray-300">
                <span 
                    className="font-medium text-gray-200">Website: </span>
                    {user.website}
            </p>
        </div>
    );
};

export default UserCard;
